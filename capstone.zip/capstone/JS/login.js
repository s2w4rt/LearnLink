
    function toggleForms() {
      const loginForm = document.getElementById('login-form');
      const registerForm = document.getElementById('register-form');
      
      if (loginForm.style.display === 'none') {
        loginForm.style.display = 'block';
        registerForm.style.display = 'none';
      } else {
        loginForm.style.display = 'none';
        registerForm.style.display = 'block';
      }
    }

    function handleLogin(event) {
      event.preventDefault();
      const username = document.getElementById('nathan').value;
      const password = document.getElementById('acosta').value;

      if (username && password) {
        window.location.href = 'home.html';
      }
    }

    function handleRegister(event) {
      event.preventDefault();
      const name = document.getElementById('register-name').value;
      const email = document.getElementById('register-email').value;
      const username = document.getElementById('register-username').value;
      const password = document.getElementById('register-password').value;

      if (name && email && username && password) {
        alert('Registration successful! Please login.');
        toggleForms();
      }
    }


    