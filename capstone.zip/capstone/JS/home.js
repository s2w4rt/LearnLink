// Current date
        const currentDate = new Date();
        let currentMonth = 4; // May (0-indexed)
        let currentYear = 2025;
        
        // Sample data
        const announcements = [
            {
                id: 1,
                title: "Office 365 Services - Important Security Update",
                content: "Starting April 23, 2024, all students and employees will be required to activate Multi-Factor Authentication (MFA) to access Office 365 services.",
                date: "2024-04-10"
            },
            {
                id: 2,
                title: "ABS CBN News is bringing",
                content: "Special coverage of campus events starting next week.",
                date: "2024-04-08"
            }
        ];
        
        const tasks = [
            { id: 1, text: "Set profile description", completed: false },
            { id: 2, text: "Complete Math assignment", completed: false }
        ];
        
        const calendarEvents = {
            "2025-05-12": "Today's classes",
            "2025-05-15": "Deadline: Science project",
            "2025-05-20": "Campus event",
            "2025-05-25": "Holiday"
        };
        
        // Initialize the dashboard
        document.addEventListener('DOMContentLoaded', function() {
            renderAnnouncements();
            renderCalendar();
            renderTodoList();
            document.getElementById('current-year').textContent = new Date().getFullYear();
        });
        
        // Announcements functions
        function renderAnnouncements() {
            const container = document.getElementById('announcements-container');
            container.innerHTML = '';
            
            announcements.forEach(announcement => {
                const announcementEl = document.createElement('div');
                announcementEl.className = 'announcement-item';
                announcementEl.innerHTML = `
                    <h6 class="fw-bold mb-1">${announcement.title}</h6>
                    <p class="small mb-1">${announcement.content}</p>
                    <span class="announcement-date">${formatDate(announcement.date)}</span>
                `;
                announcementEl.addEventListener('click', () => viewAnnouncement(announcement.id));
                container.appendChild(announcementEl);
            });
        }
        
        function addAnnouncement() {
            const input = document.getElementById('new-announcement');
            const text = input.value.trim();
            
            if (text) {
                const newAnnouncement = {
                    id: announcements.length + 1,
                    title: text,
                    content: "New announcement details...",
                    date: new Date().toISOString().split('T')[0]
                };
                
                announcements.unshift(newAnnouncement);
                renderAnnouncements();
                input.value = '';
            }
        }
        
        function viewAnnouncement(id) {
            const announcement = announcements.find(a => a.id === id);
            if (announcement) {
                alert(`ANNOUNCEMENT DETAILS\n\nTitle: ${announcement.title}\n\n${announcement.content}\n\nDate: ${formatDate(announcement.date)}`);
            }
        }
        
        // Calendar functions
        function renderCalendar() {
            const container = document.getElementById('calendar-container');
            const monthYearEl = document.getElementById('current-month');
            
            // Set month/year header
            const monthNames = ["January", "February", "March", "April", "May", "June",
                                "July", "August", "September", "October", "November", "December"];
            monthYearEl.textContent = `${monthNames[currentMonth]} ${currentYear}`;
            
            // Get first day of month and total days
            const firstDay = new Date(currentYear, currentMonth, 1).getDay();
            const daysInMonth = new Date(currentYear, currentMonth + 1, 0).getDate();
            
            // Create calendar table
            let calendarHTML = `
                <table class="table table-borderless small">
                    <thead>
                        <tr>
                            <th>S</th>
                            <th>M</th>
                            <th>T</th>
                            <th>W</th>
                            <th>T</th>
                            <th>F</th>
                            <th>S</th>
                        </tr>
                    </thead>
                    <tbody>
                        <tr>
            `;
            
            // Add empty cells for days before the first day of the month
            for (let i = 0; i < firstDay; i++) {
                calendarHTML += '<td></td>';
            }
            
            // Add days of the month
            let dayCount = 1;
            let isToday = false;
            
            for (let i = firstDay; i < 42; i++) {
                if (dayCount > daysInMonth) break;
                
                if (i % 7 === 0 && i !== 0) {
                    calendarHTML += '</tr><tr>';
                }
                
                const dateStr = `${currentYear}-${String(currentMonth + 1).padStart(2, '0')}-${String(dayCount).padStart(2, '0')}`;
                isToday = currentDate.getDate() === dayCount && 
                          currentDate.getMonth() === currentMonth && 
                          currentDate.getFullYear() === currentYear;
                
                const hasEvent = calendarEvents[dateStr];
                
                calendarHTML += `
                    <td>
                        <div class="calendar-day ${isToday ? 'today' : ''} ${hasEvent ? 'has-event' : ''}" 
                             onclick="viewDayEvents('${dateStr}')">
                            ${dayCount}
                        </div>
                    </td>
                `;
                
                dayCount++;
            }
            
            calendarHTML += '</tr></tbody></table>';
            container.innerHTML = calendarHTML;
        }
        
        function previousMonth() {
            currentMonth--;
            if (currentMonth < 0) {
                currentMonth = 11;
                currentYear--;
            }
            renderCalendar();
        }
        
        function nextMonth() {
            currentMonth++;
            if (currentMonth > 11) {
                currentMonth = 0;
                currentYear++;
            }
            renderCalendar();
        }
        
        function viewDayEvents(dateStr) {
            const event = calendarEvents[dateStr];
            if (event) {
                alert(`Events for ${formatDate(dateStr)}:\n\n• ${event}`);
            }
        }
        
        // To-Do List functions
        function renderTodoList() {
            const container = document.getElementById('todo-container');
            container.innerHTML = '';
            
            // Show only incomplete tasks
            const incompleteTasks = tasks.filter(task => !task.completed);
            
            if (incompleteTasks.length === 0) {
                container.innerHTML = '<p class="text-muted small">No tasks to show</p>';
                return;
            }
            
            incompleteTasks.forEach(task => {
                const taskEl = document.createElement('div');
                taskEl.className = 'task-item';
                taskEl.innerHTML = `
                    <span>${task.text}</span>
                    <div class="task-actions">
                        <button class="btn btn-sm btn-outline-success" onclick="completeTask(${task.id})">
                            <i class="fas fa-check"></i>
                        </button>
                        <button class="btn btn-sm btn-outline-danger" onclick="deleteTask(${task.id})">
                            <i class="fas fa-trash"></i>
                        </button>
                    </div>
                `;
                container.appendChild(taskEl);
            });
        }
        
        function addTask() {
            const input = document.getElementById('new-task');
            const text = input.value.trim();
            
            if (text) {
                tasks.push({
                    id: tasks.length + 1,
                    text: text,
                    completed: false
                });
                renderTodoList();
                input.value = '';
            }
        }
        
        function completeTask(id) {
            const task = tasks.find(t => t.id === id);
            if (task) {
                task.completed = true;
                renderTodoList();
            }
        }
        
        function deleteTask(id) {
            const index = tasks.findIndex(t => t.id === id);
            if (index !== -1) {
                tasks.splice(index, 1);
                renderTodoList();
            }
        }
        
        // Helper functions
        function formatDate(dateStr) {
            const options = { year: 'numeric', month: 'long', day: 'numeric' };
            return new Date(dateStr).toLocaleDateString(undefined, options);
        }
        
        // Mobile sidebar toggle functionality
        function toggleSidebar() {
            document.querySelector('.sidebar').classList.toggle('active');
        }

        document.getElementById("current-year").textContent = new Date().getFullYear();

        // Add logout functionality
document.getElementById('logoutButton').addEventListener('click', function(e) {
    e.preventDefault();
    // Add any logout logic here (clear session/cookies if needed)
    window.location.href = 'landing-page.html';
});


document.addEventListener('DOMContentLoaded', function() {
    let hoverTimeout;
    const dropdown = document.querySelector('.subjects-dropdown');
    const trigger = document.getElementById('subjectsDropdown');

    // Show dropdown instantly on hover
    trigger.addEventListener('mouseenter', () => {
        clearTimeout(hoverTimeout);
        dropdown.style.display = 'block';
    });

    // Handle mouse leave with delay
    trigger.addEventListener('mouseleave', () => {
        hoverTimeout = setTimeout(() => {
            if (!dropdown.matches(':hover')) {
                dropdown.style.display = 'none';
            }
        }, 100);
    });

    // Keep dropdown open when hovering over it
    dropdown.addEventListener('mouseenter', () => {
        clearTimeout(hoverTimeout);
        dropdown.style.display = 'block';
    });

    dropdown.addEventListener('mouseleave', () => {
        hoverTimeout = setTimeout(() => {
            dropdown.style.display = 'none';
        }, 100);
    });
});