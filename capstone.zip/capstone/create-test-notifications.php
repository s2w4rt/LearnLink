<?php
require_once 'config.php';
checkStudentAuth();

$user = $_SESSION['user'];
$db = getDB();

try {
    // Get the current student's ID
    $student_id = $user['id'];
    
    // Get some assignments for this student
    $stmt = $db->prepare("
        SELECT id FROM assignments 
        WHERE strand = ? 
        LIMIT 3
    ");
    $stmt->execute([$user['strand']]);
    $assignments = $stmt->fetchAll(PDO::FETCH_COLUMN);
    
    if (empty($assignments)) {
        echo "No assignments found for this student's strand. Please create assignments first.";
        exit;
    }
    
    // Create test notifications
    $types = ['new_assignment', 'due_soon', 'graded'];
    $success_count = 0;
    
    foreach ($assignments as $index => $assignment_id) {
        $type = $types[$index % count($types)];
        $is_read = $index === 2 ? 1 : 0; // Make the third one read
        
        $stmt = $db->prepare("
            INSERT INTO student_notifications 
            (student_id, assignment_id, type, is_read, created_at) 
            VALUES (?, ?, ?, ?, NOW() - INTERVAL ? HOUR)
        ");
        
        $hours_ago = ($index + 1) * 2; // 2, 4, 6 hours ago
        $success = $stmt->execute([$student_id, $assignment_id, $type, $is_read, $hours_ago]);
        
        if ($success) {
            $success_count++;
        }
    }
    
    echo "Successfully created $success_count test notifications for student ID: $student_id";
    
} catch (Exception $e) {
    echo "Error creating test notifications: " . $e->getMessage();
}
?>