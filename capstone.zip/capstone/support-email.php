<?php
// support-email.php
require_once 'config.php';

header('Content-Type: application/json');

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $data = json_decode(file_get_contents('php://input'), true);
    
    // Here you would implement email sending logic
    // This is a basic example using PHP's mail function
    
    $to = $data['studentEmail'];
    $subject = $data['subject'];
    $message = $data['message'];
    
    if ($data['includeTemplate']) {
        $message = "Dear Student,\n\n" . $message . "\n\nBest regards,\nSchool Administration";
    }
    
    $headers = "From: admin@school.edu\r\n";
    $headers .= "Reply-To: admin@school.edu\r\n";
    $headers .= "Content-Type: text/plain; charset=UTF-8\r\n";
    
    if (mail($to, $subject, $message, $headers)) {
        // Log the email response in database
        $stmt = $pdo->prepare("INSERT INTO ticket_responses (ticket_id, response_type, content, created_by) VALUES (?, 'email', ?, 'admin')");
        $stmt->execute([$data['ticketId'], $message]);
        
        echo json_encode(['success' => true, 'message' => 'Email sent successfully']);
    } else {
        echo json_encode(['success' => false, 'message' => 'Failed to send email']);
    }
}