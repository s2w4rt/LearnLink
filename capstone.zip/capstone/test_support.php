<?php
// test_support.php - Simple test to check database connection
header('Content-Type: application/json');

try {
    $host = 'localhost';
    $dbname = 'allshs_elms';
    $username = 'root';
    $password = '';
    
    $pdo = new PDO("mysql:host=$host;dbname=$dbname;charset=utf8mb4", $username, $password);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ATTR_ERRMODE_EXCEPTION);
    
    echo json_encode(['success' => true, 'message' => 'Database connection successful!']);
    
} catch (PDOException $e) {
    echo json_encode(['success' => false, 'message' => 'Database error: ' . $e->getMessage()]);
}
?>