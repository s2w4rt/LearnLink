<?php
// test-notifications.php
require_once 'config.php';
checkStudentAuth();

$user = $_SESSION['user'];
echo "User ID: " . $user['id'] . "<br>";
echo "Student ID: " . $user['student_id'] . "<br>";

$db = getDB();

// Check if we can query the notifications table
$stmt = $db->prepare("SELECT COUNT(*) as count FROM notifications WHERE user_id = ? AND user_role = 'student'");
$stmt->execute([$user['id']]);
$count = $stmt->fetchColumn();
echo "Total notifications for this student: " . $count . "<br>";

// Check unread count
$stmt = $db->prepare("SELECT COUNT(*) as unread FROM notifications WHERE user_id = ? AND user_role = 'student' AND is_read = 0");
$stmt->execute([$user['id']]);
$unread = $stmt->fetchColumn();
echo "Unread notifications: " . $unread . "<br>";

// Show actual notifications
$stmt = $db->prepare("SELECT * FROM notifications WHERE user_id = ? AND user_role = 'student' ORDER BY created_at DESC LIMIT 5");
$stmt->execute([$user['id']]);
$notifications = $stmt->fetchAll(PDO::FETCH_ASSOC);

echo "<pre>Notifications: ";
print_r($notifications);
echo "</pre>";
?>